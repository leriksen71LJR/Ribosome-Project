# Phase 2.2 Idea: Controlled Invention

**Date:** 2026-06-23  
**Status:** Idea / Not Yet Formalized

## Core Insight

We have been treating "invention" as something that should generally be minimized or eliminated. While this is correct in many contexts (especially when good prescriptive guidance exists), invention is not inherently bad.

There is an important distinction between:

- **Uncontrolled / Undesirable Invention**: Agents inventing solutions in areas where clear, prescriptive guidance already exists or should exist. This leads to inconsistency, hidden assumptions, and maintenance problems.
- **Controlled / Desirable Invention**: Agents engaging in structured problem-solving and creative exploration when facing genuinely novel, ambiguous, or complex problems that do not yet have established solutions.

## Implication for Phase 2.2

Future work should move beyond simply trying to reduce invention. Instead, we need to design workflows that explicitly support **different modes** of agent behavior:

- A **prescriptive mode** where agents should follow existing guidance closely and minimize invention.
- A **problem-solving / inventive mode** where agents are encouraged (and properly guided) to explore, propose, and create new solutions.

This suggests that Phase 2.2 and beyond will require new documentation structures, new agent instructions, and possibly new reporting mechanisms that distinguish between "following established patterns" and "engaging in structured invention."

## Open Questions

- How do we clearly signal to an agent which mode it should operate in for a given task?
- What does "good" controlled invention look like in documentation form?
- How should the results of inventive work be captured and potentially promoted into more permanent guidance (e.g., new strategies or seams)?
- What is the right balance between encouraging creative problem-solving and maintaining system coherence?