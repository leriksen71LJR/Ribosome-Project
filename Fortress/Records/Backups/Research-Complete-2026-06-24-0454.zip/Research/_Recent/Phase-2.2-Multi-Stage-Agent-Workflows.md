# Phase 2.2 Idea: Multi-Stage Agent Workflows

**Date:** 2026-06-23  
**Status:** Idea / Not Yet Formalized

## Core Insight

Current usage of Build Agents is often treated as a relatively simple transaction: "Give the agent a prompt and let it build."

This model is too limited for more complex work. In practice, many valuable tasks involve a sequence of steps where building is only one of the later stages.

A more mature workflow might include steps such as:

1. **Discovery** – Exploring the current state of the system and understanding existing structures.
2. **Problem Analysis** – Identifying gaps, inconsistencies, or new requirements.
3. **Invention / Strategy Development** – Creating or refining strategies, seams, or new approaches.
4. **Component Updates** – Modifying or extending existing component definitions.
5. **Build / Implementation** – Generating or modifying actual code.
6. **Validation & Disclosure** – Reviewing what was done and documenting decisions.

## Implication for Phase 2.2

Phase 2.2 should begin exploring how to design and document **multi-stage workflows** for agents, rather than focusing only on single-build instructions.

This includes thinking about:
- How to structure prompts and documentation for workflows that span multiple phases.
- How agents should carry context and reasoning across different stages of work.
- What kind of intermediate artifacts (proposals, analyses, strategy drafts) should be produced and reviewed before final implementation.
- How the Steward and Research roles interact with agents across a longer workflow rather than just at the beginning and end.

## Open Questions

- What does a well-structured multi-stage workflow look like in documentation form?
- How much of the workflow should be explicitly guided by documentation versus left to agent reasoning?
- Should there be different documentation artifacts for different stages of the workflow (e.g., analysis documents, proposal documents, implementation documents)?
- How do we maintain coherence and traceability across a multi-step process?