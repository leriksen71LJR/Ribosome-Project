# Fortress Research — Structure & Rules

**Status:** Active canonical structure (as of 2026-06-21)

## Purpose

`Fortress/Research/` is the **single source of truth** for all meta-level work on the Fortress project. It exists to:

- Capture raw thinking and emerging ideas without polluting the buildable project.
- Evolve prompts, processes, and philosophy over time.
- Maintain long-term continuity and high-fidelity handoffs.
- Enable deep analysis across multiple agent runs and phases.
- Keep the "thinking space" cleanly separated from the "building space".

This folder is **human + lead researcher territory**. The local Supergrok instance (inside `Fortress/Project/`) owns the build artifacts and should generally not read or write here.

## File Naming Conventions

### Date Format in Filenames

When saving any document that includes a date in the filename, use the following format:

**`yyyy-MM-dd-hhmm`**

**Examples:**
- `Experiment-06-Analysis-2026-06-22-1926.md`
- `Daily-Work-Summary-2026-06-21-2117.md`
- `Ribosome-Project-Review-Summary-2026-06-22-1020.md`

This format provides both the full date and the exact time the document was created (24-hour clock, no colon).

## Context Management & Backup Triggers

Because these research conversations can become long and dense, we maintain awareness of context usage and back up important work proactively.

### Context Awareness
- When context usage approaches **~80%**, Research should flag it.
- When context usage approaches **~90%**, Research should strongly recommend creating a backup of key documents before continuing.

### When to Create a Backup
Create a backup (usually by saving a dated snapshot or updating the Memory Capsule) when any of the following occur:

- Before making significant structural changes to a major guidance document (e.g. Experiment 07).
- After reaching a meaningful decision point or new principle (especially if it affects how future work should be done).
- When the conversation has become very long and we are about to enter a new major phase of work.
- When the user explicitly requests a backup.

### Purpose
This practice protects high-value thinking from being lost due to context compression. It is not about saving everything — it is about protecting the principles, decisions, and documents that would be expensive to reconstruct.

## Backup Procedures

### Full Research Folder Backup

When a complete snapshot of the current Research state is needed (especially before major transitions, after significant decision points, or at the end of a work session), follow this process:

**Naming Convention:**
`Research-Complete-yyyy-MM-dd-hhmm.zip`

**Example:**
`Research-Complete-2026-06-24-1430.zip`

**Process (Must be followed in order):**

1. **Record the backup in this file first** (STRUCTURE.md) — including date/time, reason for backup, and what major work was just completed.
2. Create the zip from the **parent directory** of `Research/` (i.e. from `artifacts/`).
3. The resulting zip should be placed in `Research/Backups/` (create the folder if it does not exist).
4. After creating the zip, update this section with the final filename and location.

**Why this order matters:**
Recording the intent and context *before* creating the archive protects against situations where the backup itself fails or context is lost mid-process.

**Current Backup Location:**
`Research/Backups/`

---

## Directory Layout (Current Handoff Workspace)

**Note:** The original zip had double-nesting. On 2026-06-21 the structure was flattened for usability. The layout below reflects the cleaned state used in this Research session.

```
fortress-research-handoff/          ← Working Research root (flattened)
├── STRUCTURE.md
├── CHARTER.md
├── Current-Context.md
├── README-Handoff.md
├── Backlog/
│   └── Backlog.md
├── Export/                         ← Analysis reports & specs for Steward
├── Investigations/                 ← Research deep-dives (new)
│   └── investigation-001-2026-06-21.md
├── Memory/
│   └── Research-Memory-Capsule-2026-06-21.md
└── (Ideas/, Prompts/, Philosophy/ to be added as needed)
```

**Intended long-term structure** (when integrated into real `Fortress/Research/`):
```
Fortress/Research/
├── STRUCTURE.md
├── CHARTER.md
├── Current-Context.md
├── Backlog/
├── Export/
├── Investigations/
├── Memory/
├── Ideas/
├── Prompts/
└── Philosophy/
```

## Rules

1. **Everything that is not buildable agent input goes here.**
2. **Do not create new top-level folders** without updating this file first.
3. **Keep content high-signal.** Prefer one strong document over many fragmented ones.
4. **Date-stamp important artifacts** (e.g., `REASONING_2026-06-20.md`, `Ideas-2026-06-19.md`).
5. **Never put code, .docs/, or buildable project files here.** Those belong in `Fortress/Project/`.
6. **When in doubt, put it in `Ideas/` first** with a clear filename and date. We can promote it later.

## Current Active Areas (2026-06-21)

- **Prompts/**: Reasoning Disclosure Prompt (with gamification layer) and Build prompts.
- **ReasoningDisclosure/**: Collected outputs from Claude, Grok Build, and Codex runs.
- **Ideas/**: Ribosome model evolution, Documentation as Pseudocode, gamification experiments, Phase 2 proposals.
- **Philosophy/**: Core principles behind making documentation executable and agent-coordinated.
- **Handoffs/**: Migration notes from chat-based development to local VS Code + Continue.dev workflow.
- **Export/**: Preferred location for analysis reports and artifacts intended to move to the local project (replacing the older `Analysis/` folder).

## Relationship to Fortress/Project/

- `Fortress/Project/` = The thing agents build and maintain (AGENTS.md, .docs/, source code).
- `Fortress/Research/` = The thinking that produces and improves the rules agents follow.

These two folders should remain **strictly separated**. The local Supergrok should treat `Research/` as read-only (or out of scope) unless explicitly instructed otherwise.

---

**Last updated:** 2026-06-21 by Grok (lead researcher role) — Added Export/ folder and updated charter model  
**Next review trigger:** Major phase transition or significant prompt/process change.
## Logging Process

- A `Logs/` folder exists for daily work summaries, decision records, and process notes.
- Log files should use clear, descriptive names that include the date and time in 24-hour format (e.g. `Daily-Work-Summary-2026-06-21-1251.md` or `Phase2-Decisions-2026-06-21-1430.md`).
- Logs are created when significant work is done, key decisions are made, or at the end of focused sessions.
- The goal of logging is to preserve context, decisions, and progress without relying solely on chat history.

## Recent Files Access

When the user requests a list of "recent files", Research must ensure those files are easily accessible for download and quick use.

### Rule
- Maintain a dedicated `_Recent/` folder at the root of `Research/`.
- When listing recent or important files, copy the most relevant ones into `_Recent/` so they can be quickly opened or downloaded without navigating deep nested folders (e.g. inside `007-Phase-2.1-Guidance/Analysis/`).
- Keep `_Recent/` relatively clean — it is a convenience layer, not a permanent archive.

### Purpose
Deep experiment folder structures improve long-term organization but make frequent access to current work cumbersome. The `_Recent/` folder provides a consistent, flat, easy-to-reach location for the most active documents.

### Presentation Format (Standard Table)

When the user asks for "recent files", Research **must** present the list using this exact markdown table format:

```markdown
| File | Exists? | Notes |
|------|---------|-------|
| `filename.md` | ✅ Yes | Brief status or description |
| `another-file.md` | ✅ Yes | Good |
```

**Rules for this table:**
- Always include the three columns: **File**, **Exists?**, and **Notes**.
- Use ✅ Yes or ❌ No in the Exists? column.
- Keep the Notes column concise but useful (e.g., "Good", "Main Steward document", "Was missing — now copied").
- Prioritize the most important/relevant files at the top.
- This format is now the required standard for all "recent files" responses.

This table style was explicitly approved by the user as the preferred way to surface recent work.

